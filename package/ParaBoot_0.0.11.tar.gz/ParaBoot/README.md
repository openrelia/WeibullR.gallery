ParaBoot
========

 

Parametric bootstrap bounds for Weibull and Lognormal models.

 

This is a development package housing eventual replacement code for WeibullR
that will permit confidence interval bounds preparation with 3 parameters.  This
package has dependency on WeibullR, but does not override any WeibullR
functionality.

 
