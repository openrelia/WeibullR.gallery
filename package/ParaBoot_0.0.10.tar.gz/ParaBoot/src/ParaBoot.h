#ifndef _ParaBoot_H
#define _ParaBoot_H

#include <RcppArmadillo.h>

RcppExport SEXP LSLR2(SEXP arg1);
RcppExport SEXP pivotalMC2(SEXP arg1);

		
#endif

